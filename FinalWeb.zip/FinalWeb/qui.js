
let questions = [
    {
         number:1,
         question: "When was the decision made to rename the Kazakh SSR into the Republic of Kazakhstan?",
         answer : "December 10, 1991",
         options : [
                          "December 10, 1991",
                          "December 10, 1989",
                          "December 16, 1990",
                          "December 16, 1992"
                        ]
    
    },
    {
         number:2,
         question: " In what year were the State Flag and Coat of Arms of the Republic approved?",
         answer : "June 4, 1992",
         options : [
                          "June 6, 1990",

                          "June 4, 1992",
                          
                          "August 30, 1991"
                          ,
                          "December 16, 1991"  
                          ]
    
    },
   {
         number:3,
         question: "What event happened on December 16, 1991?",
         answer : "The law on statehood of independence of the Republic of Kazakhstan was adopted",
         options : [ 
                          "Declaration on state sovereignty of the Republic of Kazakhstan adopted",
                          "The President signed the Lisbon Treaty",
                          "The law on statehood of independence of the Republic of Kazakhstan was adopted",
                          "Language law adopted "
                          ]
    
    },
    {
         number:4,
         question: "What does HTTP stanNational currency - tenge - introduced in Kazakhstan...?d for ?",
         answer : "November 15, 1993",
         options : [
                          "November 14, 1992",
                          "June 4, 1992",
                          "June 4, 1993",
                          "November 15, 1993 "
                          ]
    }, 
    {
         number:5,
         question: "Hero of Kazakh folk tales.",
         answer : "Aldar Kose",
         options : [ 
                          "Aldar Kose",
                          "Ivan the Fool",
                          "Emelya",
                          "Pinocchio"
                       ]
    },
    {
         number:6,
         question: "Kazakh musical instrument.",
         answer : "Dombra",
         options : [
                          "Dombra",
                          "Harmonic",
                          "Balalaika",
                          "Gusli"
                       ]
    },
    {
         number:7,
         question: "What is a flag, coat of arms, anthem for a state?",
         answer : "Symbols of the state",
         options : [
                          "Symbols of the state",
                          "Historical monuments",
                          "Coins",
                          "Museum exhibits"
                       ]
    },
     {
         number:8,
         question: "Which of these cities is not included in the Republic of Kazakhstan?",
         answer : "Omsk",
         options : [
                         "Omsk",
                         "Karaganda",
                         "Almaty",
                         "Aktobe"
                       ]
    },
    {
         number:9,
         question: "Where are the books from Elbasy's personal library stored?",
         answer : "Library of the First President of the Republic of Kazakhstan",
         options : [
                         "Palace of Peace and Reconciliation",
                         "Palace of Independence",
                         "Library of the First President of the Republic of Kazakhstan",
                         "None"
                       ]
    },
    {
         number:10,
         question: "In what year did Kazakhstan become a member of the UN?",
         answer : "in 1992",
         options : [
                         "in 1993",
                         "in 1992",
                         "in 1997",
                         "in 1998"
                       ]
    }


     ];    